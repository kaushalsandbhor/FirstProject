# Banking-Application-using-Java
Basic command line banking application. It is just a introduction mini project.


### OUTPUT :

Banking Menu: 
Select any one option from below. 
1) Add Customer
2) Change Customer Name
3) Check Account Balance
4) Update Account Balance
5) Summary of All Accounts
6) Quit
Enter your option: 1

Add Customer Menu    

Enter Customer Name: Abhishek Tripathi
Enter Opening Balance Amount: 1000
Account created successfully. 

Account Details:- 
 
Account Number: 0
Account Name: Abhishek Tripathi
Account Balance: 1000.0 Rs 

Banking Menu:
Select any one option from below.
1) Add Customer
2) Change Customer Name
3) Check Account Balance
4) Update Account Balance
5) Summary of All Accounts
6) Quit
Enter your option: 1

Add Customer Menu

Enter Customer Name: Sweta Shukla
Enter Opening Balance Amount: 5000 
Account created successfully. 

Account Details:-

Account Number: 1
Account Name: Sweta Shukla
Account Balance: 5000.0 Rs

Banking Menu: 
Select any one option from below.
1) Add Customer
2) Change Customer Name
3) Check Account Balance
4) Update Account Balance
5) Summary of All Accounts
6) Quit
Enter your option: 2

Change Customer Name Menu

Enter your Account Number: 1
Enter the new name: Shweta Shukla
Name is successfully updated from Sweta Shukla to Shweta Shukla. 

Banking Menu: 
Select any one option from below.
1) Add Customer
2) Change Customer Name
3) Check Account Balance
4) Update Account Balance
5) Summary of All Accounts
6) Quit
Enter your option: 3

Check Account Balance Menu

Enter your Account Number: 1
Shweta Shukla your balance is 5000.0Rs.
Banking Menu:
Select any one option from below.
1) Add Customer
2) Change Customer Name
3) Check Account Balance
4) Update Account Balance
5) Summary of All Accounts
6) Quit
Enter your option: 4

Update Account Balance Menu

Enter your Account Number: 0
Enter the amount to be deposited: 10000
Abhishek Tripathi your updated balance is : 11000.0 RS. 

Banking Menu:
Select any one option from below.
1) Add Customer
2) Change Customer Name
3) Check Account Balance
4) Update Account Balance
5) Summary of All Accounts
6) Quit
Enter your option: 5
Account Number: 0, Name: Abhishek Tripathi, Balance: 11000.0Rs. 

Account Number: 1, Name: Shweta Shukla, Balance: 5000.0Rs.

Banking Menu:
Select any one option from below.
1) Add Customer
2) Change Customer Name
3) Check Account Balance
4) Update Account Balance
5) Summary of All Accounts
6) Quit
Enter your option: 6
Terminating...


### Changes that you can make:

Instead of using incremental account number you can use random function to generate random number and add it to accountNumber array.
