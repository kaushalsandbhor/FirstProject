package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
@Repository
public interface EmpRepository extends JpaRepository<Employee, Integer> {
	
	public Employee findById(int Id);


}
