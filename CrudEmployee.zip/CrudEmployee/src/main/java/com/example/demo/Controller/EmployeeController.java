package com.example.demo.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;

@RestController
public class EmployeeController {
	
	
	
	List<Employee>emp=new ArrayList<>();
	
  public List<Employee> getAllEmployees() {
	  Employee emp=new Employee(1,"Aditya",20000);  
	return null;
		
	}

}
