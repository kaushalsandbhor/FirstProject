package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.Service.EmpService;
import com.example.demo.Service.EmpServiceImpl;
import com.example.demo.model.Employee;
@SpringBootApplication
public class CrudEmployeeApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=SpringApplication.run(CrudEmployeeApplication.class, args);
		EmpService empService=context.getBean(EmpServiceImpl.class);
		Scanner sc=new Scanner(System.in);
		Employee emp1=new Employee();
		int id,ch;
		String name;
		float salary;
		String ch2;
		do {
		System.out.println("1.Insert \n2.Delete \n3.Update \n4.Display \n5.Exit");
		ch=sc.nextInt();
		switch(ch) {
		case 1:
			System.out.println("Enter a Id :");
			id=sc.nextInt();
			System.out.println("Enter a name : ");
			name=sc.next();
			System.out.println("Enter a Salary :");
			salary=sc.nextFloat();
			empService.addEmployee(emp1);	
			break;
		case 2:
			System.out.println("Enter a Id :");
			id=sc.nextInt();
			empService.deleteEmployee(id);
			break;
		case 3:
			System.out.println("Enter a Id :");
			id=sc.nextInt();
			System.out.println("Enter a name : ");
			name=sc.next();
		    System.out.println("Enter a Salary :");
			salary=sc.nextFloat();
			empService.updateEmployeeById(emp1, id);
			break;
		case 4:
			System.out.println("Enter the employee id:");
			id=sc.nextInt();
			Employee emp=empService.getEmployeeById(id);
			System.out.println(emp);
			break;	
		case 5:
		  List<Employee>empList=new ArrayList<Employee>();
		  empList=empService.getAllEmployees();
		  for(Employee e:empList)
			  System.out.println(e);
		  break;
	}System.out.println("do you want to continue press yes");
	ch2=sc.next();	
}while(ch2=="yes");	
	}	
}